//
//  ViewController.swift
//  XML
//
//  Created by MACOS on 6/15/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,XMLParserDelegate {

    var arr = [Any]()
    var brr = [String]()
    var str = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.news%20%20where%20region%3D%22in%22&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0")
        
        do
        {
            let dt = try Data(contentsOf: url!)
            
            let xml = XMLParser(data: dt)
            xml.delegate = self
            xml.parse()
        }
        catch
        {
            
        }
    }
    
    func parserDidStartDocument(_ parser: XMLParser) {
        arr = [Any]()
    }
    
    func parserDidEndDocument(_ parser: XMLParser) {
        print(arr)
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
         if elementName == "item"
         {
            brr = [String]()
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "author" ||
        elementName == "link" ||
        elementName == "title"
        {
            brr.append(str)
        }
        else if(elementName == "item")
        {
            arr.append(brr)
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        str = string
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = arr[indexPath.row] as! [String]
        
        cell?.textLabel?.text = dicfinal[2] as! String?
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nav = self.storyboard?.instantiateViewController(withIdentifier: "next") as! First
        
        let dicfinal = arr[indexPath.row] as! [String]
        nav.st = dicfinal[1]
        self.navigationController?.pushViewController(nav, animated: true)
    }


}

